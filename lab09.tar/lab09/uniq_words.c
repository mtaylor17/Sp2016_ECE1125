/* 	Lab 09
	Part 2.1
	Matt Taylor	*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int process_line(char *line, size_t n, int * freq, char *string)
{
	int flag = 1;
	static int line_count = 1;
	if(line_count == 1){
		free(string);
		string = malloc(strlen(line) * sizeof(char));
		strcpy(string, line);
		line_count ++;
		*freq = 1;
		return 0;
	}
	else{
		if(strcmp(line, string) != 0){
			flag = 0;
		}
		else{
			flag = 1;
		}
	}
	
	if(flag == 1){
		*freq += 1;
	}
	if(flag == 0){
		printf("%12d\t%s\n", *freq, string);
		free(string);
		*freq = 1;
		string = malloc(strlen(line) * sizeof(char));
		strcpy(string, line);		
	}
	line_count ++;
	return 0;
}

int main(int argc, char *argv[])
{
	int frequency = 1;
	int *f_p = &frequency;
	int exit_status = 0;
	char * string = malloc(2 * sizeof(char));
	
	FILE *fp;
	if (argc < 2) {
		fp = stdin;
	}
	else {
		fp = fopen(argv[1], "r");
		if (!fp) {
			fprintf(stderr, "Error opening %s: %s\n", argv[1], strerror(errno));
			exit(1);
		}
	}
	size_t n = 0;
	char *lineptr = 0;
	for (;;) {
		ssize_t rc = getline(&lineptr, &n, fp);
		if (rc < 0) {
			break;
		}
		if (rc > 0) {
			if (process_line(lineptr, rc, f_p, string) < 0) {
				exit_status = 1;
				free(lineptr);
				break;
			}
		}
		free(lineptr);
		lineptr = 0;
		n = 0;
	}
	if (ferror(fp)) {
		fprintf(stderr, "Error reading %s: %s\n", argv[1], strerror(errno));
		exit_status = 1;
	}
	fclose(fp);
	exit(exit_status);
}
